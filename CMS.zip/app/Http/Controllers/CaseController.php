<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\CaseRequest;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Route;
use App\Lawcase;
use Auth;
use Session;

class CaseController extends Controller
{
    public function addCaseForm(){
        return view('addcase');
    }

    public function showAllCases(){
        $data = Lawcase::where('fk_user_id','=',Auth::id())->where('case_status','!=','decided')->paginate(20);
        return view('allcases')->with('allcasesdata',$data);
    }

    public function showTodayCases(){
        $today = date('Y-m-d');
        $data = Lawcase::where('fk_user_id','=',Auth::id())->where('case_status','!=','decided')->where('next_date','=',$today)->paginate(20);
        return view('todaycases')->with('allcasesdata',$data);
    }

    public function showNextCases(){
        $nextday = date('Y-m-d' , strtotime('+1 days'));
        $data = Lawcase::where('fk_user_id','=',Auth::id())->where('case_status','!=','decided')->where('next_date','=',$nextday)->paginate(20);
        return view('nextcases')->with('allcasesdata',$data);
    }

    public function showPendingCases(){
        $data = Lawcase::where('fk_user_id','=',Auth::id())->where('case_status','!=','decided')->where('next_date','<',date('Y-m-d'))->paginate(20);
        return view('pendingcases')->with('allcasesdata',$data);
    }

    public function showDecidedCases(){
        $data = Lawcase::where('fk_user_id','=',Auth::id())->where('case_status','=','decided')->paginate(20);
        return view('decidedcases')->with('allcasesdata',$data);
    }
    
    public function showEditPage($caseid){
        $id = Crypt::decrypt($caseid);
        $data = Lawcase::where('fk_user_id','=',Auth::id())->where('case_id','=',$id)->first();
        return view('editcasepage')->with('casedata',$data);
    }
    
    public function addCaseInDb(CaseRequest $request){
        $cases = new Lawcase;
        $cases->where('fk_user_id','=',Auth::id());
        $cases->fill($request->all());
        $cases->fk_user_id = Auth::id();
        $cases->save();
        return back();
    }
    
    public function changeStatus($caseid){
        $id = Crypt::decrypt($caseid);
        $cases = Lawcase::find($id);
        $cases->case_status = 'decided';
        $cases->save();
        Session::flash('message', 'Case Status is changed to DECIDED. You can access all decided cases in "Decided Cases" button!'); 
        Session::flash('alert-class', 'alert-danger'); 
        return redirect()->route('All Cases')->with('message' , 'Case Status is changed to DECIDED. You can access all decided cases in "Decided Cases" button!');
    }
    
    public function updateCaseData(Request $request){
        $cases = new Lawcase;
        $cases = Lawcase::find(Crypt::decrypt($request->case_id));
        $cases->fill($request->all());
        $cases->save();
        ?>
        <script>
            window.history.go(-2)
        </script>
        <?php
    }
    
    public function deleteCase($id){
        Lawcase::destroy(Crypt::decrypt($id));
        Session::flash('message', 'Your Case has been deleted'); 
        Session::flash('alert-class', 'alert-danger'); 
        return back();

    }
}
