@extends('layout.template')
@section('content')

<script>
        $(document).ready(function () {
          // Handler for .ready() called.
          $('html, body').animate({
              scrollTop: $('#allcase').offset().top
          }, 'slow');
        });
      </script>

<div class="main-content" style="padding-top:10px;" id="allcase">
                {{-- <div class="section__content section__content--p30"> --}}
                    {{-- <div class="container-fluid"> --}}
                        {{-- <div class="row text-center">
                                <h3 class="ml-auto mr-auto line" style="color:black; margin-bottom:20px">All Cases</h3>
                        </div> --}}  
            {{-- @if(Session::has('message'))
                <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('message') }}</p>
            @endif             --}}

                        <div class="row" id="allcaserow">
                            <div class="col-lg-12">
                                <div class="table-responsive table--no-card m-b-30">
                                    <table class="table"  id="casestable">
                                        <input type="text" class="form-control" id="tablesearch" onkeyup="myFunction()" placeholder="Search ">
                                        <thead>
                                            <tr >
                                                <th style="width:8%;">Serial No</th>
                                                <th style="width:17%">Case Title</th>
                                                <th style="width:13%">Court Name</th>
                                                <th style="width:10%">Case Nature</th>
                                                <th style="width:11%">Previous Date</th>
                                                <th style="width:8%">Next Date</th>
                                                <th style="width:7%">Reference</th>
                                                <th style="width:9%">Case Status</th>
                                                <th style="width:8%">Actions</th>

                                            </tr>
                                        </thead>
                                        <tbody style="text-align:center; background-color:white; ">
                                            <?php $serial = 1; ?>
                                            @foreach ($allcasesdata as $case)
                                            <tr>
                                                <td>{{$serial++}}</td>
                                                <td>{{$case->case_title}}</td>
                                                <td>{{$case->court_name}}</td>
                                                <td>{{$case->case_nature}}</td>
                                                <td>{{date('d-m-Y',strtotime($case->previous_date))}}</td>
                                                <td>{{date('d-m-Y',strtotime($case->next_date))}}</td>
                                                <td>{{$case->reference}}</td>
                                                <td>{{$case->case_status}}</td>
                                                <td>
                                                    @include('partials.buttons')
                                                </td>

                                            </tr>
                                            @endforeach
                                            
                                            
                                        </tbody>
                                    </table>
                                </div>
                                <span>{{ $allcasesdata->links() }}</span>
                            </div> 
                            
                            
                        </div>
                    {{-- </div> --}}
                    <hr>
                            <div class="row" >
                                <div class="col-md-12">
                                    <div class="copyright">
                                        <p>Copyright © <?php echo date('Y')?> CMS. All rights reserved.</p>
                                    </div>
                                </div>
                            </div>


                            
                            @endsection