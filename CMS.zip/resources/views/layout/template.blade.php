
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

    @include('partials.header')
    <body class="animsition">
    @include('partials.navbar')
    <?php $data = Helper::cardData(); 
    
    ?>
    @include('partials.cards' , ['data' => $data])
    @yield('content')
    @include('partials.footer')
    </body>
</html>
