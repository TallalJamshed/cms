<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Auth::routes();

// Route::get('/',function(){
//     return view('index');
// });
Route::get('/', 'HomeController@index')->name('Home');
Route::get('/dGrjrxQQss', 'HomeController@index')->name('Home');
Route::get('/T9VB9yDdDz', 'CaseController@addCaseForm')->name('Add New Case');
Route::get('/fafdsfdsgf', 'CaseController@addCaseForm')->name('Add New Task');
Route::get('/GFw0dxQQvl', 'CaseController@showAllCases')->name('All Cases');
Route::get('/jyVuXDz7D5', 'CaseController@showTodayCases')->name('Today Cases');
Route::get('/IVKNV81GSJ', 'CaseController@showNextCases')->name('Next Day Cases');
Route::get('/IO4l9YfpQO', 'CaseController@showPendingCases')->name('Pending Cases');
Route::get('/YYGZcW4wBy', 'CaseController@showDecidedCases')->name('Decided Cases');
Route::get('/XELPkXBB5B/{id}', 'CaseController@showEditPage')->name('Edit Case');
/////////////////Perform Action///////////////
Route::post('/LgfFP1ax6D', 'CaseController@addCaseInDb')->name('addcaseindb');
Route::get('/V9uLoJsID4/{id}', 'CaseController@changeStatus')->name('changestatus');
Route::post('/khIJuhyQi3', 'CaseController@updateCaseData')->name('updatecase');
Route::get('/DWERDSFEEE/{id}', 'CaseController@deleteCase')->name('deletecase');

Route::get('/dsahfeuhkf' , 'TaskController@showTaskPage')->name('Add New Task');
Route::post('/saderesfef' , 'TaskController@addTaskInDb')->name('addtaskindb');
Route::get('/safsafeeww/{id}' , 'TaskController@showEditTaskPage')->name('Edit Task');
Route::get('/r00pZ6wNIR/{id}', 'TaskController@deleteTask')->name('deletetask');
Route::get('/rewqffferr','TaskController@nextTasks')->name('Next Tasks');
Route::get('/rsfsafnvrr','TaskController@previousTasks')->name('Previous Tasks');
Route::get('/jsandehfkj/{id}','TaskController@getDownload')->name('getdownload');
Route::post('/sfiuwgksaj','TaskController@updateTaskData')->name('updatetask');
