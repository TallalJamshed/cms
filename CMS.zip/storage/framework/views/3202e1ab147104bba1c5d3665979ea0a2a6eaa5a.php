
<!-- MAIN CONTENT-->
<div class="main-content">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="overview-wrap">
                        
                        <a data-toggle="tooltip" data-placement="bottom" title="Add New Cases" href="<?php echo e(route('Add New Case')); ?>">
                            <button class="au-btn btn-lg au-btn-icon au-btn--gray" id="buttonadd">
                                <i class="zmdi zmdi-plus" style="font-weight: 1000" ></i>add cases
                            </button>
                        </a>

                        <h1 class="fullview"><u> <?php echo \Request::route()->getName() ; ?> </u></h1>
                        <a data-toggle="tooltip" data-placement="bottom" title="Show Decided Cases" href="<?php echo e(route('Decided Cases')); ?>">
                            <button class="au-btn btn-lg au-btn-icon au-btn--gray top-space" id="buttonadd">
                                <i class="fas fa-check"></i>decided cases
                            </button>
                        </a>
                        <h1 class="halfview"><u> <?php echo \Request::route()->getName() ; ?> </u></h1>
                        
                        
                    </div>
                    <hr>
                </div>
            </div>
            <div class="row m-t-25">
                <div  class="col-sm-6 col-lg-3">
                    <div data-toggle="tooltip" data-placement="bottom" title="Show All Available Cases" class="overview-item overview-item--c1">
                        <a  href="<?php echo e(route('All Cases')); ?>" id="allcasebtn">
                        <div class="overview__inner">
                            <div class="overview-box clearfix">
                                <div class="icon">
                                    <i class="far fa-folder-open"></i>
                                </div>
                                <div class="text">
                                <h2><?php echo e($data['allcases']); ?></h2>
                                    <span>All Cases</span>                                   
                                </div>
                            </div>    
                        </div>
                        </a>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3">
                    <div data-toggle="tooltip" data-placement="bottom" title="Show Todays Cases" class="overview-item overview-item--c1">
                        <a href="<?php echo e(route('Today Cases')); ?>">
                        <div class="overview__inner">
                            <div class="overview-box clearfix">
                                <div class="icon">
                                    <i class="fa fa-tasks"></i>
                                    
                                </div>
                                <div class="text">
                                    <h2><?php echo e($data['todaycases']); ?></h2>
                                    <span>Today Cases</span>
                                </div>
                            </div>                            
                        </div>
                        </a>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3">
                    <div data-toggle="tooltip" data-placement="bottom" title="Show Next Day Cases" class="overview-item overview-item--c1">
                        <a href="<?php echo e(route('Next Day Cases')); ?>">
                        <div class="overview__inner">
                            <div class="overview-box clearfix">
                                <div class="icon">
                                        <i class="fa fa-mail-forward"></i>
                                    
                                </div>
                                <div class="text">
                                    <h2><?php echo e($data['nextdaycases']); ?></h2>
                                    <span>Next Day Cases</span>
                                </div>
                            </div>  
                        </div>
                        </a>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3">
                    <div data-toggle="tooltip" data-placement="bottom" title="Show All Cases Who's Next Date Is Not Updated" class="overview-item overview-item--c1">
                        <a href="<?php echo e(route('Pending Cases')); ?>">
                        <div class="overview__inner">
                            <div class="overview-box clearfix">
                                <div class="icon">
                                    <i class="fa fa-calendar-times-o"></i>
                                    
                                </div>
                                <div class="text">
                                    <h2><?php echo e($data['pendingcases']); ?></h2>
                                    <span>Pending Cases</span>
                                </div>
                            </div>   
                        </div>
                        </a>
                    </div>
                </div>
            </div>
            <hr style="font-weight:1000">