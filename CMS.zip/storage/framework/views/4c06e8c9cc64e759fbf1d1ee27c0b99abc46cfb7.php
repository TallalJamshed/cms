

<!-- Bootstrap JS-->
<script src="<?php echo e(asset('vendor/bootstrap-4.1/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/bootstrap-4.1/bootstrap.min.js')); ?>"></script>
<!-- Vendor JS       -->
<script src="<?php echo e(asset('vendor/slick/slick.min.js')); ?>">
</script>
<script src="<?php echo e(asset('vendor/wow/wow.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/animsition/animsition.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/bootstrap-progressbar/bootstrap-progressbar.min.js')); ?>">
</script>
<script src="<?php echo e(asset('vendor/counter-up/jquery.waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/counter-up/jquery.counterup.min.js')); ?>">
</script>
<script src="<?php echo e(asset('vendor/circle-progress/circle-progress.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/perfect-scrollbar/perfect-scrollbar.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/chartjs/Chart.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/select2/select2.min.js')); ?>">
</script>
<script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js">
</script>
<script src="https://cdn.datatables.net/autofill/2.3.1/js/dataTables.autoFill.min.js"></script>



<!-- Main JS-->
<script src="<?php echo e(asset('js/main.js')); ?>"></script>

<script>
    $(document).ready(function(){
        $('[data-toggle="tooltip"]').tooltip();   
    });
</script>

<script type="text/javascript" src="<?php echo e(asset('js/bootstrap-filestyle.min.js')); ?>"> </script>
<script>
$(":file").filestyle();
</script>

<script>
        function myFunction() {
          // Declare variables 
          var input, filter, table, tr, td, i, txtValue;
          input = document.getElementById("tablesearch");
          filter = input.value.toUpperCase();
          table = document.getElementById("casestable");
          tr = table.getElementsByTagName("tr");
        
          // Loop through all table rows, and hide those who don't match the search query
          for (i = 0; i < tr.length; i++) {
            td = tr[i].getElementsByTagName("td")[1];
            if (td) {
              txtValue = td.textContent || td.innerText;
              if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = "";
              } else {
                tr[i].style.display = "none";
              }
            } 
          }
        }
        </script>




