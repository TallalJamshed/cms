<?php $__env->startSection('content'); ?>
<div id="bodycontent">
<div class="row ">
    
    <div class="col-lg-12 ">
        <div class="au-card au-card--no-shadow au-card--no-pad m-b-40">
            <div class="au-card-title" style="background-image:url('images/bg-title-01.jpg');">
                <div class="bg-overlay bg-overlay--blue">
                </div>                    
                <div class="col-md-12" >
                    <div class="col-md-5" style="display:inline-block">
                        <h3>
                            <i class="zmdi zmdi-account-calendar"></i>
                            <?php echo date('d M Y')?>
                        </h3>
                    </div>
                    <div class="col-md-1" style="display:inline-block">
                    </div>
                    <div class="col-md-5" style="display:inline-block; float:right">
                        <h3 class="taskday" >
                            <i class="zmdi zmdi-account-calendar"></i>
                            <?php echo date('l')?>
                        </h3>
                    </div>
                </div>    
            <a href="<?php echo e(route('Add New Task')); ?>" style="">
                <button class="au-btn-plus">
                    <i class="zmdi zmdi-plus"></i>
                </button>
            </a>

            </div>
            <div class="au-task js-list-load">
                
               
                <div class="row " style="margin:20px; overflow:hidden;">
                    <div class="col-md-4 top-space" align="center">
                        <a data-toggle="tooltip" data-placement="bottom" title="Show All Previous Tasks" href="<?php echo e(route('Previous Tasks')); ?>">
                            <button class="au-btn btn-lg au-btn-icon au-btn--gray" style="width:100%;">
                                <i class="fa fa-chevron-left" style="font-weight: 650" ></i>Previous Tasks
                            </button>
                        </a>
                    </div>

                    <div class="col-md-4 top-space" align="center">
                        <a data-toggle="tooltip" data-placement="bottom" title="Show Todays Tasks" href="<?php echo e(route('Home')); ?>">
                            <button class="au-btn btn-lg au-btn-icon au-btn--gray" style="width:100%;">
                                Today's Tasks
                            </button>
                        </a>
                    </div>

                    <div class="col-md-4 top-space" align="center">
                        <a data-toggle="tooltip" data-placement="bottom" title="Show All Upcoming Tasks" href="<?php echo e(route('Next Tasks')); ?>">
                            <button class="au-btn btn-lg au-btn-icon au-btn--gray" style="width:100%">
                                Next Day Tasks <i class="fa fa-chevron-right" style="font-weight: 650" ></i>
                            </button>
                        </a>
                    </div>
                </div>

                <div class="au-task-list js-scrollbar3" style="max-height:420px; overflow-y:scroll">
                    <?php 
                        if (count($task)>0) {
                            foreach ($task as $key => $value) {                             
                    ?>
                        <div class="row" style="margin-bottom:-30px; width:100%">
                            <div class="col-md-10 au-task__item-inner" style="display:inline-block">
                                <h5 class="task">
                                    <a href="#"><?php echo e($value->task_detail); ?></a>
                                </h5>
                                <span class="time"><?php echo e(date('h:i A' , strtotime($value->task_time))); ?></span>
                            </div>
                            
                                
                                       
                            
                            <div class="col-md-2 au-task__item-inner" align="center" style="display:inline-block">
                                <?php echo $__env->make('partials.taskbuttons', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </div>
                        </div>
                        <hr>
                    <?php  
                            }
                        }
                        else { 
                    ?>
                        <div class="col-md-12 au-task__item-inner" align="center" style="display:inline-block;">
                            <?php echo e("You have no tasks for today."); ?>

                            <hr>
                        </div>
                    <?php  
                        }
                    ?>
                </div>
            </div>
        </div>
    </div>
    
</div>

<div class="row">
    <div class="col-md-12">
        <div class="copyright">
                <p>Copyright © <?php echo date('Y')?> CMS. All rights reserved.</p>
        </div>
    </div>
</div>

</div>
</div>
</div>
<!-- END MAIN CONTENT-->
<!-- END PAGE CONTAINER-->
</div>

</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>