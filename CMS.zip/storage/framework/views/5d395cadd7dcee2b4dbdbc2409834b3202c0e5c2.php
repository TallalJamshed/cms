<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12 col-xl-12">
        <div class="" style="background-color:white; border:1px solid gray; border-radius: 5px;">
            <div class="form-header" style="">
                <i class="fas fa-pencil-alt" id="addcaseitag" ></i><span id="addcasespantag">Edit Case<span>
            </div>
            <div class="form-body">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <form class="form-horizontal" method="POST" action="<?php echo e(route('updatecase')); ?>" >
                    
                    
                    
                    <?php echo csrf_field(); ?>
                    <div class="row addcaserow" >
                        <input type="text" hidden="true" name="case_id" value="<?php echo e(Crypt::encrypt($casedata->case_id)); ?>">
                        <label class="control-label col-md-2 addcaselabel" style="padding-right:0px" for="">Case Title:
                        </label>
                        <div class="col-md-4" style="padding-left:0px">
                        <input class="form-control<?php echo e($errors->has('case_title') ? ' is-invalid' : ''); ?>" type="text" name="case_title" id="case_title" value="<?php echo e($casedata->case_title); ?>" placeholder="Enter Case Title">
                        </div>

                        <label class="control-label col-md-2 addcaselabel" style="padding-right:0px" for="">Case Nature:
                        </label>
                        <div class="col-md-4" style="padding-left:0px">
                            <input class="form-control<?php echo e($errors->has('case_nature') ? ' is-invalid' : ''); ?>" type="text" name="case_nature" id="case_nature" value="<?php echo e($casedata->case_nature); ?>" placeholder="Enter Case Nature">
                        </div>
                    </div>

                    <div class="row addcaserow">
                        <label class="control-label col-md-2 addcaselabel" style="padding-right:0px" for="">Court Name:
                        </label>
                        <div class="col-md-4" style="padding-left:0px">
                            <input class="form-control<?php echo e($errors->has('court_name') ? ' is-invalid' : ''); ?>" type="text" name="court_name" id="court_name" value="<?php echo e($casedata->court_name); ?>" placeholder="Enter Case Title">
                        </div>

                        <label class="control-label col-md-2 addcaselabel" style="padding-right:0px" for="">Reference:
                        </label>
                        <div class="col-md-4" style="padding-left:0px">
                            <input class="form-control<?php echo e($errors->has('reference') ? ' is-invalid' : ''); ?>" type="text" name="reference" id="reference" value="<?php echo e($casedata->reference); ?>" placeholder="Enter Case Title">
                        </div>
                    </div>
                    
                    <div class="row addcaserow">
                        <label class="control-label col-md-2 addcaselabel" style="padding-right:0px" for="">Previous Date:
                        </label>
                        <div class="col-md-4" style="padding-left:0px">
                            <input class="form-control<?php echo e($errors->has('previous_date') ? ' is-invalid' : ''); ?>" type="date" name="previous_date" id="previous_date" value="<?php echo e($casedata->previous_date); ?>" >
                        </div>

                        <label class="control-label col-md-2 addcaselabel" style="padding-right:0px" for="">Next Date:
                        </label>
                        <div class="col-md-4" style="padding-left:0px">
                            <input class="form-control<?php echo e($errors->has('next_date') ? ' is-invalid' : ''); ?>" type="date" name="next_date" id="next_date" value="<?php echo e($casedata->next_date); ?>" >
                        </div>
                    </div>

                    <div class="row addcaserow">
                        <label class="control-label col-md-2 addcaselabel" style="padding-right:0px" for="">Case Status:
                        </label>
                        <div class="col-md-10" style="padding-left:0px">
                            <textarea class="form-control<?php echo e($errors->has('case_status') ? ' is-invalid' : ''); ?>" name="case_status" id="case_status" rows="5" placeholder="Enter Case Status"><?php echo e($casedata->case_status); ?></textarea>
                        </div>
                    </div>

                    <div class="row addcaserow" >
                        <div class="col-md-12" style="text-align:center">
                            <input type="submit" value="submit" id="submitbutton" class="btn btn-primary"> 
                        </div>      
                    </div>
                    
                    
                </form>

            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="copyright">
            <p>Copyright © 2018 Colorlib. All rights reserved. Template by <a href="https://colorlib.com">Colorlib</a>.</p>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>