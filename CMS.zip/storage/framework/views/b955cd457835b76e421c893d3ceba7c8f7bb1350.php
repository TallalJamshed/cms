<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12 col-xl-12">
        <div class="" style="background-color:white; border:1px solid gray; border-radius: 5px;">
            <div class="form-header" style="">
                <i class="fas fa-plus" id="addcaseitag" ></i><span id="addcasespantag">Add New Task<span>
            </div>
            <div class="form-body">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <form class="form-horizontal" method="POST" action="<?php echo e(route('addtaskindb')); ?>" enctype="multipart/form-data" >
                    
                    
                    
                    <?php echo csrf_field(); ?>

                    <div class="row addcaserow justify-content-center">
                        <label class="control-label col-md-2 addcaselabel" style="padding-right:0px" for="">Task Due Date:
                        </label>
                        <div class="col-md-4" style="padding-left:0px">
                            <input class="form-control<?php echo e($errors->has('task_date') ? ' is-invalid' : ''); ?>" type="date" name="task_date" id="task_date" value="<?php echo e(old('task_date')); ?>" placeholder="Enter Task Date">
                        </div>
                    </div>
                    
                    <div class="row addcaserow justify-content-center">
                        <label class="control-label col-md-2 addcaselabel" style="padding-right:0px" for="">Task Due Time:<sub style="color:grey">*optional</sub>
                        </label>
                        <div class="col-md-4" style="padding-left:0px">
                            <input class="form-control<?php echo e($errors->has('task_time') ? ' is-invalid' : ''); ?>" type="time" name="task_time" id="task_time" value="<?php echo e(old('task_time')); ?>" placeholder="Enter Task Time">
                        </div>
                    </div>

                    

                    <?php if($errors->has('extension')): ?>
                        <div class="row addcaserow justify-content-center" >
                            <span style="color:red"><?php echo e("Only PDF Files are allowed"); ?></span>
                        </div>
                    <?php endif; ?>

                    <div class="row addcaserow justify-content-center">
                        <label class="control-label col-md-2 addcaselabel" style="padding-right:0px" for="">Task Details:
                        </label>
                        <div class="col-md-4" style="padding-left:0px">
                            <textarea class="form-control<?php echo e($errors->has('task_detail') ? ' is-invalid' : ''); ?>" name="task_detail" id="task_detail" value="<?php echo e(old('task_detail')); ?>" rows="5" placeholder="Enter Task Detail"></textarea>
                        </div>
                    </div>

                    <div class="row addcaserow justify-content-center" >
                        <div class="col-md-4" style="text-align:center">
                            <input type="submit" value="submit" id="submitbutton" class="btn btn-primary"> 
                        </div>      
                    </div>
                    
                    
                </form>

            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="copyright">
                <p>Copyright © <?php echo date('Y')?> CMS. All rights reserved.</p>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>