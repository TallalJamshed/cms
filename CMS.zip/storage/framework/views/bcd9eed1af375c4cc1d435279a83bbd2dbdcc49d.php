<a data-toggle="tooltip" data-placement="auto" title="Finish this case. All finished cases will be available in Decided Cases button" class="red-tooltip" href="<?php echo e(route('changestatus' , Crypt::encrypt($case->case_id))); ?>"><button class="btn btn-sm btn-success"><i class="far fa-eye-slash"></i></button></a>
<a data-toggle="tooltip" data-placement="auto" title="Press this button to edit this case" class="red-tooltip" href="<?php echo e(route('Edit Case', Crypt::encrypt($case->case_id))); ?>"><button class="btn btn-sm btn-info"><i class="fas fa-pencil-alt"></i></button></a>
<button class="btn btn-sm btn-danger" data-toggle="modal" data-target="#staticModal"><i class="far fa-trash-alt"></i></button>

<!-- modal static -->
<div class="modal fade" id="staticModal" tabindex="-1" role="dialog" aria-labelledby="staticModalLabel" aria-hidden="true"
data-backdrop="static">
   <div class="modal-dialog " role="document">
       <div class="modal-content">
           <div class="modal-header">
               <h5 class="modal-title" id="staticModalLabel">Static Modal</h5>
               <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                   <span aria-hidden="true">&times;</span>
               </button>
           </div>
           <div class="modal-body">
               <p>
                   Do you really want to delete this case.
               </p>
           </div>
           <div class="modal-footer">
               <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
               <a href="<?php echo e(route('deletecase' , Crypt::encrypt($case->case_id))); ?>"><button type="button" class="btn btn-primary" id="confirmDelete">Confirm</button></a>
           </div>
       </div>
   </div>
</div>
<!-- end modal static -->